import numpy as np
from sklearn.neighbors import KNeighborsClassifier


class Classifier():
    def __init__(self, model, verbose=True):
        self.model = model
        self.name = "Generic Classifier"
        self.verbose = verbose
     
    def _loadTrainDataset(self, dataloader):
        X_train = []
        y_train = []
        
        for i, ((img_norm, label), d_idx) in enumerate(dataloader):
            if self.verbose:
                print(f"[INFO] Extracting features: batch {i+1}/{len(dataloader)}", end='\r')
            features = self.model(img_norm.cuda())
            
            X_train.append(features.cpu())
            y_train.append(label)
        if self.verbose:
            print(''*20)
        return np.concatenate(X_train, axis=0), np.concatenate(y_train, axis=0)
        
    def fit(self, dataloader_train):        
        X_train, y_train = self._loadTrainDataset(dataloader_train)
                
        if self.verbose:
            print(f"\n[INFO] Fitting {self.name}")
        self.classifier.fit(X_train, y_train)
        if self.verbose:
            print("[INFO] Done!")
        
    def predict(self, X_test):
        embedding = self.model(X_test[None].cuda()).cpu().numpy()
        return self.classifier.predict(embedding)
    
    def evaluate(self, dataloader_test):
        X_test, y_trues = self._loadTrainDataset(dataloader_test)
        
        y_preds = []
        print("\n ------")
        for i, embedding in enumerate(X_test):
            if self.verbose:
                print(f"Test Data Evaluated: {i+1}/{X_test.shape[0]}", end='\r')
                        
            y_pred = self.classifier.predict(embedding[None])
            
            y_preds.append(y_pred)
        return y_trues, y_preds

    
class KNNClassifier(Classifier):
    def __init__(self, n_neighbors=5, metric='minkowski', p=2, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.classifier = KNeighborsClassifier(n_neighbors=n_neighbors, metric=metric, p=p)
        self.name = "KNN Classifier"