import os

path = 'correct_txt_lists'
path_to_add = '/home/vitto/Documents/DL_Projects/Homework3-PACS/'

files = os.listdir(path)
#os.mkdir(path + '_new')
for f in files:
    new_text = []
    f_cont = open(os.path.join(path, f), 'r')
    r = open(path + '_new' + '/' + f, 'w')
    for l in f_cont:
        t = l.split()
        t[0] = path_to_add + t[0]
        r.write(' '.join(t) + '\n')

    
